#include "../include/tokenizer.h"
#include <cstddef>
#include <fstream>
#include <iostream>
#include <regex>
#include <string>

using namespace token;
using namespace std;

regex whitespace_or_newline("[\s\n]");


Tokenizer::Tokenizer(string filename) {
        filename = filename;
        // layer one starts
        state.new_state = 0;
        state.letter_start = 0;
        state.non_zero_digit_start = 0;
        state.zero_start = 0;
        state.special_char_start = 0;
        state.single_char_operator_start = 0;
        state.single_line_comment_start = 0;
        state.multi_line_comment_start = 0;

        // layer two starts
        state.interger_start = 0;
        state.fraction_start = 0;
        state.two_char_operator_start = 0;

        // state status
        state.new_state = 1;

        outputErrorsFileName = filename + ".outlexerrors";
        outputTokensFileName =filename + ".outlextokens";
        setupOutputFile();
}

size_t Tokenizer::IngestChar(const char *c) {
        cmatch match;
        // regex whitespace_or_newline("[\\s\\n]");
        regex whitespace_or_newline("^[\\s\\n]");

        // Debug: Print current input character
        // std::cout << "Ingesting char: '" << *c << "'" << std::endl;

        if (regex_search(c, match, whitespace_or_newline)) {
                size_t offset = match.length();
                // std::cout << "Skipping whitespace or newline, offset: " << offset << std::endl;
                return offset;
        } else {
                // std::cout << "New token detected" << std::endl;
                return NewToken(c);
        }
}

size_t Tokenizer::NewToken(const char *c) {
        // Define regex patterns
        regex whitespace_or_newline("[\\s\\n]");
        regex id_token("^[a-zA-Z][a-zA-Z0-9_]*(?=[\\s\\n]|\\z)");
        regex interger_token("^(0|[1-9][0-9]*)(?=[\\s\\n]|\\z)");
        regex float_token("^(0|[1-9][0-9]*)(\\.(0|[1-9][0-9]*))?(e[+-]?(0|[1-9][0-9]*))?(?=[\\s\\n]|\\z)");
        regex single_line_comment("^//.*\\n");
        regex multi_line_comment("/\\*.*?\\*/");
        regex operators("^(==|<>|<=|>=|:=|=>|\\+|\\-|\\*|\\/|<|>|\\(|\\)|\\{|\\}|\\[|\\]|;|:|,|\\.)(?=[\\s\\n]|\\z)");
        regex fraction("^\\.(\\d*[1-9])(?=[\\s\\n]|\\z)");
        regex reserved("and|or|not|if|then|else|while|for|return|void|self|class|attribute|constructor|float|int|isa|read|write|public|private|local|function|implemetation");


        cmatch match;

        // Check for various token types
        if (regex_search(c, match, id_token)) {
                if (regex_match(match.str(), reserved)) {
                        std::cout << "reserved token: " << match.str() << std::endl;
                        writeTokens(match.str());
                } else {
                        std::cout << "id token: " << match.str() << std::endl;
                        writeTokens(match.str());
                }
                return match.length();
        } else if (regex_search(c, match, fraction)) {
                std::cout << "fraction token: " << match.str() << std::endl;
                writeTokens(match.str());
                return match.length();
        } else if (regex_search(c, match, interger_token)) {
                std::cout << "integer token: " << match.str() << std::endl;
                writeTokens(match.str());
                return match.length();
        } else if (regex_search(c, match, float_token)) {
                std::cout << "float token: " << match.str() << std::endl;
                writeTokens(match.str());
                return match.length();
        } else if (regex_search(c, match, single_line_comment)) {
                std::cout << "single-line comment token: " << match.str() << std::endl;
                writeTokens(match.str());
                return match.length();
        } else if (regex_search(c, match, multi_line_comment)) {
                std::cout << "multi-line comment token: " << match.str() << std::endl;
                writeTokens(match.str());
                return match.length();
        } else if (regex_search(c, match, operators)) {
                std::cout << "operator token: " << match.str() << std::endl;
                writeTokens(match.str());
                return match.length();
        } else {
                // std::cerr<<" Bad token : " << endl;
        }

        // If no match, return 1 to move the pointer forward
        return 1;
}


void Tokenizer::setupOutputFile() {

        ofstream tokens(outputTokensFileName, ios::app);
        ofstream erros(outputErrorsFileName, ios::app);

        if (tokens.is_open()) {
        } else {
                cerr << "ERROR opening token file " << filename + ".tokens" << endl;
        }

        if (erros.is_open()) {
        } else {
                cerr << "ERROR opening token file " << filename + ".errors" << endl;
        }
}


void Tokenizer::writeTokens(const string &token) {
        std::cerr << token << endl;
        std::ofstream file(outputTokensFileName, std::ios::app);
        if (file.is_open()) {
                file << token;
                file.close();
        } else {
                std::cerr << "Error opening file for appending: " << filename << std::endl;
        }
}
void Tokenizer::writeErrors(const string &error) {
        std::ofstream file(outputErrorsFileName, std::ios::app);
        if (file.is_open()) {
                file << error;
                file.close();
        } else {
                std::cerr << "Error opening file for appending: " << filename << std::endl;
        }
}
